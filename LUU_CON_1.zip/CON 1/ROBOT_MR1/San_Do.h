void reset_all()
{
    resetIMU();
    RESET_ENCODER();
}




/*******************KHAI BAO GIA TRI LAZE NGANG***************************/
void thong_so_laze_ngang_doc(void)
{
        if      (lan_trong == 1 && hang_trong == 1)     {lazengang = LAZENGANG_1[SAN][1],  lazedoc = LAZEDOC[hang_trong],                                   laze_doc_truot = LAZEDOC[3];}
        else if (lan_trong == 1 && hang_trong == 2)     {lazengang = LAZENGANG_1[SAN][2],  lazedoc = LAZEDOC[hang_trong], laze_ngang_ve = LAZE_VE[SAN][0],  laze_doc_truot = LAZEDOC[4];}
        
        if      (lan_trong == 2 && hang_trong == 1)     {lazengang = LAZENGANG_1[SAN][3],  lazedoc = LAZEDOC[hang_trong],                                   laze_doc_truot = LAZEDOC[3];}
        else if (lan_trong == 2 && hang_trong == 2)     {lazengang = LAZENGANG_1[SAN][4],  lazedoc = LAZEDOC[hang_trong], laze_ngang_ve = LAZE_VE[SAN][1],  laze_doc_truot = LAZEDOC[4];}    
        
        if      (lan_trong == 3 && hang_trong == 1)     {lazengang = LAZENGANG_1[SAN][5],  lazedoc = LAZEDOC[hang_trong],                                   laze_doc_truot = LAZEDOC[3];}
        else if (lan_trong == 3 && hang_trong == 2)     {lazengang = LAZENGANG_1[SAN][6],  lazedoc = LAZEDOC[hang_trong];}
}

void luu_thong_so_laze(void)
{
    if(SAN == 1)
    {
        
    }
    else
    {
        
    }
}



void ve_lay_lua()
{
    RESET_ENCODER();
    if(SAN == 1)
    {
        if(lan_trong!=3)
        {   
            robotRunAngle(0, 20, 0, 0);
            while(ENCODER_TONG() < 6) {if(wantExit()) break; vTaskDelay(1);}

            robotRunAngle(900, 25, 0, 0);	 
            while(lazeNgangValue > laze_ngang_ve){if(wantExit()) break; vTaskDelay(1);}
//            
//            robotStop(2);
//            
//            robotRunAngle(-1800, 80, 0, 0);	 
//            while(lazeTruocValue < laze_doc_truot-5){if(wantExit()) break; vTaskDelay(1);}
//                        
//            robotStop(2);
//            
//            robotRunAngle(-1800, 20, 0, 0);	 
//            while(lazeTruocValue < 304){if(wantExit()) break; vTaskDelay(1);}
            
            for(i=0;i<50;i++)   while(lazeTruocValue < laze_doc_truot-20)        bam_thanh_laze_ngang(1800, 80, 0, -30, laze_ngang_ve, 2);
            for(i=0;i<50;i++)   while(lazeTruocValue < 304)                     bam_thanh_laze_ngang(1800, 20, 0, -30, laze_ngang_ve, 2);
                        
            if(lazeNgangValue < laze_ngang_ve)
            {
                robotRunAngle(-900, 10, 0, 0);
                while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1){if(wantExit()) break; vTaskDelay(1);}
            }
            if(lazeNgangValue > laze_ngang_ve)
            {
                robotRunAngle(900, 10, 0, 0);
                while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1){if(wantExit()) break; vTaskDelay(1);}
            }

//            reset_all();
//            
//            robotRunAngle(-1800, 20, 0, 0);	 
//            while(ENCODER_TONG() < 20){if(wantExit()) break; vTaskDelay(1);}
            
        }
        else
        {
            HOT_BANH_ON;
            delay_ms(100);
            KEO_LUA_LEN;
            TAY_GAP_LEN;
        }
    }
    else
    {
        if(lan_trong!=3)
        {
            robotRunAngle(0, 20, 0, 0);
            while(ENCODER_TONG() < 6) {if(wantExit()) break; vTaskDelay(1);}

            robotRunAngle(-900, 25, 0, 0);
            while(lazeNgangValue < laze_ngang_ve){if(wantExit()) break; vTaskDelay(1);}

            robotRunAngle(1800, 80, 0, 0);	 
            while(lazeTruocValue < laze_doc_truot){if(wantExit()) break; vTaskDelay(1);}
            
            robotRunAngle(1800, 20, 0, 0);	 
            while(lazeTruocValue < 304){if(wantExit()) break; vTaskDelay(1);}
            
            if(lazeNgangValue > laze_ngang_ve)
            {
                robotRunAngle(900, 10, 0, 0);
                while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1){if(wantExit()) break; vTaskDelay(1);}
            }
            if(lazeNgangValue < laze_ngang_ve)
            {
                robotRunAngle(-900, 10, 0, 0);
                while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1){if(wantExit()) break; vTaskDelay(1);}
            }
//            
//            reset_all();
//            
//            robotRunAngle(-1800, 20, 0, 0);	 
//            while(ENCODER_TONG() < 20){if(wantExit()) break; vTaskDelay(1);}
        }
        else
        {
            HOT_BANH_ON;
            KEO_LUA_LEN;
            TAY_GAP_LEN;
        }
    }
}

void quy_trinh_trong_lua_hang_1()
{
/****************************************LEN TRONG LUA*************************************************/    
    thong_so_laze_ngang_doc();
    
    KEP_LUA_13_KEP;
    KEP_LUA_24_KEP;
    delay_ms(200);
    KEO_LUA_LEN;
    delay_ms(500);
    
    reset_all();

/****************************************TRONG LUA HANG 1**************************************************/        
/****************************************SAN DO**************************************************/ 
    if(SAN == 1)
    {   
//        robotRunAngle(-900, 15, 0, 0);
//        while(lazeNgangValue < lazengang){if(wantExit()) break; vTaskDelay(1);}
//                
//        robotStop(2);
//        
//        robotRunAngle(0, 80, 10, 0);
//        while(lazeTruocValue > laze_doc_truot){if(wantExit()) break; vTaskDelay(1);}

//        robotRunAngle(0, 25, -10, 0);
//        while(lazeTruocValue > lazedoc){if(wantExit()) break; vTaskDelay(1);}
        
        for(i=0;i<50;i++)   while(lazeTruocValue > laze_doc_truot+9)        bam_thanh_laze_ngang(0, 80, 0, 100, lazengang, 2);
        for(i=0;i<50;i++)   while(lazeTruocValue > lazedoc+13)              bam_thanh_laze_ngang(0, 25, 0, 100, lazengang, 2);
        
        
        robotStop(2);
        
        KEO_LUA_XUONG;
        
    }
/****************************************SAN XANH**************************************************/ 
    else
    {        
        robotRunAngle(900, 15, 0, 0);
        while(lazeNgangValue > lazengang){if(wantExit()) break; vTaskDelay(1);}
        
        robotStop(2);
        
        robotRunAngle(0, 80, 0, 0);
        while(lazeTruocValue > laze_doc_truot){if(wantExit()) break; vTaskDelay(1);}

        robotRunAngle(0, 25, 0, 0);
        while(lazeTruocValue > lazedoc){if(wantExit()) break; vTaskDelay(1);}
        
        robotStop(2);

        KEO_LUA_XUONG;
    }
}    
    
/****************************************TRONG LUA HANG 2**************************************************/            
void quy_trinh_trong_lua_hang_2()
{    
    thong_so_laze_ngang_doc();
    
    if(SAN == 1)
    {   
//        robotRunAngle(0, 20, 0, 0);
//        while(lazeTruocValue > lazedoc-3){if(wantExit()) break; vTaskDelay(1);}
//        robotStop(2);
//        robotRunAngle(900, 20, 0, 0);	 
//        while(lazeNgangValue > lazengang){if(wantExit()) break; vTaskDelay(1);}
        
        for(i=0;i<50;i++)   while(lazeTruocValue > lazedoc-7)          bam_thanh_laze_ngang(0, 20, 0, 450, lazengang, 2);
    }
    else
    {
        robotRunAngle(0, 20, 0, 0);
        while(lazeTruocValue > lazedoc){if(wantExit()) break; vTaskDelay(1);}
        robotStop(2);
        robotRunAngle(-900, 20, 0, 0);
        while(lazeNgangValue < lazengang){if(wantExit()) break; vTaskDelay(1);}
    }    
    
}

void trong_lua()
{
    if(SAN == 1)
    {
        if(hang_trong == 1)         
        {
            KEP_LUA_13_NHA;
            hang_trong = 2;
            delay_ms(100);
            quy_trinh_trong_lua_hang_2();
        }
        else
        {
            thong_so_laze_ngang_doc();
            KEP_LUA_24_NHA;
            delay_ms(100);
            ve_lay_lua();
            lan_trong++;
            hang_trong = 1;
        }
    }
    else
    {
        if(hang_trong == 2)
        {
            thong_so_laze_ngang_doc();
            KEP_LUA_13_NHA;
            delay_ms(200);
            ve_lay_lua();
            lan_trong++;
            hang_trong = 1;
            
        }
        else 
        {
            KEP_LUA_24_NHA;
            hang_trong = 2;
            delay_ms(200);
            quy_trinh_trong_lua_hang_2();

        }
    }
}


void len_san_2(void)
{
    robotStop(2);
    RESET_ENCODER();
//    KEO_LUA_LEN;
//    vTaskDelay(3333);
//    HOT_BANH_ON;
    robotRunAngle(0, 20, 0, 0);	 
    while(ENCODER_TONG() < 1500){if(wantExit()) break; vTaskDelay(1);}
}

void banthoc(void)
{
    if(CB_HOT_BONG==0)
    {
        NAP_DAN_ON;
        HOT_BANH_OFF;
        vTaskDelay(2222);
        Mor_xoay_phai = 254, Mor_xoay_phai_thuan;
		Mor_xoay_trai = 254, Mor_xoay_trai_thuan;
        vTaskDelay(5555);
        Mor_xoay_phai = Mor_xoay_trai = 0;
    }
    HOT_BANH_ON;
}

/////////////////////////////////  RETRY  ////////////////////////////////////
void retry (void)
{
    reset_all();
    hang_trong = 2;
    
/****************************************DI CHUYEN LAY LUA TIEP THEO*************************************************/	
    thong_so_laze_ngang_doc();
    
    if(SAN == 1)
    {
        robotRunAngle(900, 15, 0,0);
        while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1) {if(wantExit()) break; vTaskDelay(1);}
    }
    else
    {
        robotRunAngle(-900, 15, 0,0);
        while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1) {if(wantExit()) break; vTaskDelay(1);}
    }
    
    lan_trong++;
    hang_trong = 1;
    
}
///////////////////////////////// XUAT PHAT///////////////////////////////////
int XuatPhat(void)
{
    reset_all();
    
/****************************************DI CHUYEN LAY LUA*************************************************/	
	if(SAN == 1)
    {   
        robotRunAngle(450, 50, 650, 0);
        while(lazeTruocValue > 310) {if(wantExit()) break;  vTaskDelay(1);}
        
        chuanbicocau();
        
        robotRunAngle(900, 25, 0, 0);
        while(lazeNgangValue > 272) {if(wantExit()) break;  vTaskDelay(1);}
                
        robotRunAngle(1800, 13, 0, 0);
        while(lazeTruocValue < 304){if(wantExit()) break; vTaskDelay(1);}  
        
        if(lazeNgangValue < 258)
        {
            robotRunAngle(-900, 10, 0, 0);
            while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1){if(wantExit()) break; vTaskDelay(1);}
        }
        else if(lazeNgangValue > 261)
        {
            robotRunAngle(900, 10, 0, 0);
            while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1){if(wantExit()) break; vTaskDelay(1);}
        }
        
        lan_trong++;
    }
    else
    {        
        robotRunAngle(-450, 50, -650, 0);
        while(lazeTruocValue > 310) {if(wantExit()) break;  vTaskDelay(1);}
        
        chuanbicocau();
        
        robotRunAngle(-900, 20, 0, 0);
        while(lazeNgangValue < 195){if(wantExit()) break; vTaskDelay(1);}  
        
        robotRunAngle(1800, 15, 0, 0);
        while(lazeTruocValue < 304){if(wantExit()) break; vTaskDelay(1);}  
        
        if(lazeNgangValue > 198)
        {
            robotRunAngle(900, 10, 0, 0);
            while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1){if(wantExit()) break; vTaskDelay(1);}
        }
        else if(lazeNgangValue < 196)
        {
            robotRunAngle(-900, 10, 0, 0);
            while(CB_KEP_LUA_1 == 1 || CB_KEP_LUA_4 == 1){if(wantExit()) break; vTaskDelay(1);}
        }
        
        lan_trong++;
        
    }
}